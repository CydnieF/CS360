package com.cs360.myapplication;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class AddDataActivity extends AppCompatActivity {

    // Declare views
    private EditText dateForWeights, userWeight;
    private FloatingActionButton plusButton, backArrowButton;
    private WeightTrackerDatabase db;

    // Initialize views and database
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        // Initialize views
        dateForWeights = findViewById(R.id.dateForWeights);
        userWeight = findViewById(R.id.userWeight);
        plusButton = findViewById(R.id.plusButton);
        backArrowButton = findViewById(R.id.backArrowButton);

        // Initialize database
        db = WeightTrackerDatabase.getInstance(this);

        // Set up plus button click listener to save data
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });

        // Set up back arrow button click listener to navigate back
        backArrowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Closes the activity and returns to the previous one
            }
        });
    }

    // Save data to the database
    private void saveData() {
        String date = dateForWeights.getText().toString().trim();
        String weightStr = userWeight.getText().toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(date)) {
            Toast.makeText(this, "Please enter a date", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(weightStr)) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert weight to double
        try {
            double weight = Double.parseDouble(weightStr);

            // Insert data into the database
            boolean isInserted = db.addWeight(date, weight);

            // Handle the result
            if (isInserted) {
                Toast.makeText(this, "Data saved successfully", Toast.LENGTH_SHORT).show();
                finish(); // Closes the activity and returns to the previous one
            } else {
                Toast.makeText(this, "Failed to save data", Toast.LENGTH_SHORT).show();
            }

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight value", Toast.LENGTH_SHORT).show();
        }
    }
}
