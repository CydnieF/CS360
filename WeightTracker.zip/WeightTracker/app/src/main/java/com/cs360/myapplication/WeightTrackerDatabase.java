package com.cs360.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class WeightTrackerDatabase extends SQLiteOpenHelper {

    // Logcat tag
    private static final String LOG = "DatabaseHelper";

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "weightTracker.db";

    // Singleton instance
    private static WeightTrackerDatabase sInstance;

    // Table names and columns
    private static final class UsersTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "user_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    private static final class WeightsTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "weight_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }

    // Singleton pattern
    public static synchronized WeightTrackerDatabase getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new WeightTrackerDatabase(context.getApplicationContext());
        }
        return sInstance;
    }

    // Private constructor to prevent multiple instances
    public WeightTrackerDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(LOG, "Creating database");

        String CREATE_USERS_TABLE = "CREATE TABLE " + UsersTable.TABLE + " ("
                + UsersTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + UsersTable.COL_USERNAME + " TEXT, "
                + UsersTable.COL_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_WEIGHTS_TABLE = "CREATE TABLE " + WeightsTable.TABLE + " ("
                + WeightsTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + WeightsTable.COL_DATE + " TEXT, "
                + WeightsTable.COL_WEIGHT + " REAL)";
        db.execSQL(CREATE_WEIGHTS_TABLE);
    }

    // Upgrade database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i(LOG, "Upgrading database");
        db.execSQL("DROP TABLE IF EXISTS " + UsersTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + WeightsTable.TABLE);
        onCreate(db);
    }

    // Create a new user
    public boolean addUser(String username, String password) {
        // Check if username already exists
        if (usernameExists(username)) {
            return false;
        }
        // Insert new user
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_USERNAME, username);
        values.put(UsersTable.COL_PASSWORD, password);

        // Insert the new row, returning the primary key value of the new row
        long userId = db.insert(UsersTable.TABLE, null, values);
        return userId != -1;
    }

    // Check if user exists with the given credentials
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + UsersTable.TABLE + " WHERE "
                + UsersTable.COL_USERNAME + " = ? AND "
                + UsersTable.COL_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Check if username already exists
    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + UsersTable.TABLE + " WHERE " + UsersTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{username});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Add a weight entry
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightsTable.COL_DATE, date);
        values.put(WeightsTable.COL_WEIGHT, weight);

        long weightId = db.insert(WeightsTable.TABLE, null, values);
        return weightId != -1;
    }

    // Get all weight entries
    public List<WeightEntry> getAllWeights() {
        List<WeightEntry> weightEntries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM weights", null);

        // Check if the cursor has any rows
        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex("weight_id");
            int dateIndex = cursor.getColumnIndex("date");
            int weightIndex = cursor.getColumnIndex("weight");

            // Check if the column indices are valid
            if (idIndex != -1 && dateIndex != -1 && weightIndex != -1) {
                do {
                    int id = cursor.getInt(idIndex);
                    String date = cursor.getString(dateIndex);
                    double weight = cursor.getDouble(weightIndex);
                    weightEntries.add(new WeightEntry(id, date, weight));
                } while (cursor.moveToNext());
            }
        }
        cursor.close();
        return weightEntries;
    }


    // Update a weight entry
    public boolean updateWeight(WeightEntry entry) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightsTable.COL_DATE, entry.getDate());
        values.put(WeightsTable.COL_WEIGHT, entry.getWeight());

        int rowsUpdated = db.update(WeightsTable.TABLE, values, WeightsTable.COL_ID + " = ?",
                new String[]{String.valueOf(entry.getId())});
        return rowsUpdated > 0;
    }

    // Delete a weight entry
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(WeightsTable.TABLE, WeightsTable.COL_ID + " = ?", new String[]{String.valueOf(id)}) > 0;
    }

}
