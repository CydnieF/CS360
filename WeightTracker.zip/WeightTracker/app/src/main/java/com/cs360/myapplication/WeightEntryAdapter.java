package com.cs360.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class WeightEntryAdapter extends BaseAdapter {

    // Context and data
    private Context context;
    private List<WeightEntry> weightEntries;
    private WeightTrackerDatabase db;

    // Constructor
    public WeightEntryAdapter(Context context, List<WeightEntry> weightEntries, WeightTrackerDatabase db) {
        this.context = context;
        this.weightEntries = weightEntries;
        this.db = db;
    }

    // Getters
    @Override
    public int getCount() {
        return weightEntries.size();
    }

    @Override
    public Object getItem(int position) {
        return weightEntries.get(position);
    }

    @Override
    public long getItemId(int position) {
        return weightEntries.get(position).getId();
    }

    // getView method
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // Inflate the layout for each item
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_layout, parent, false);
        }

        // Get references to the TextViews and buttons
        TextView dateTextView = convertView.findViewById(R.id.date);
        TextView weightTextView = convertView.findViewById(R.id.weight);
        Button editButton = convertView.findViewById(R.id.editButton);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);

        final WeightEntry entry = weightEntries.get(position);

        dateTextView.setText(entry.getDate());
        weightTextView.setText(String.valueOf(entry.getWeight()));

        // Set up the delete button click listener
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.deleteWeight(entry.getId());
                weightEntries.remove(position);
                notifyDataSetChanged();
                Toast.makeText(context, "Weight entry deleted", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up the edit button click listener
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDialog(entry);
            }
        });

        return convertView;
    }

    // Helper method to show the edit dialog
    private void showEditDialog(final WeightEntry entry) {
        // Create a dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.activity_edit_weight, null);
        builder.setView(dialogView);

        // Get references to the EditText fields
        final EditText editTextDate = dialogView.findViewById(R.id.dateForWeights);
        final EditText editTextWeight = dialogView.findViewById(R.id.userWeight);

        // Set the initial values of the EditText fields from the WeightEntry object
        editTextDate.setText(entry.getDate());
        editTextWeight.setText(String.valueOf(entry.getWeight()));

        // Set the colors
        int textColor = Color.parseColor("#667866");
        editTextDate.setTextColor(textColor);
        editTextDate.setHintTextColor(textColor);
        editTextWeight.setTextColor(textColor);
        editTextWeight.setHintTextColor(textColor);

        // Add "Save" button to the dialog
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Update the WeightEntry object with the new values
                String newDate = editTextDate.getText().toString();
                String newWeight = editTextWeight.getText().toString();

                if (!newDate.isEmpty() && !newWeight.isEmpty()) {
                    entry.setDate(newDate);
                    entry.setWeight(Double.parseDouble(newWeight));

                    // Update the database
                    boolean updated = db.updateWeight(entry);  // Corrected line
                    if (updated) {
                        // Notify the adapter about the change
                        notifyDataSetChanged();
                        Toast.makeText(context, "Weight entry updated", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Add "Cancel" button to the dialog
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();

        // Set the color of the dialog buttons
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(textColor);
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(textColor);
    }
}
