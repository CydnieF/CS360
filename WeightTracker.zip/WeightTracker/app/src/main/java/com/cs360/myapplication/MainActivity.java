package com.cs360.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Declare database helper
    private WeightTrackerDatabase weightTrackerDatabase;
    private EditText usernameEditText;
    private EditText passwordEditText;

    // Override onCreate method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        weightTrackerDatabase = new WeightTrackerDatabase(this);

        // Initialize EditTexts
        usernameEditText = findViewById(R.id.userUsername);
        passwordEditText = findViewById(R.id.userPassword);

        // Login button click listener
        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (login(username, password)) {
                    // Navigate to Data Display screen
                    Intent intent = new Intent(MainActivity.this, DataActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Invalid login credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Create Account button click listener
        Button createAccountButton = findViewById(R.id.createAccountButton);
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (createAccount(username, password)) {
                    Toast.makeText(MainActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Account creation failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Dummy method to simulate login functionality.
    private boolean login(String username, String password) {
        return weightTrackerDatabase.checkUser(username, password);
    }

    // Dummy method to simulate account creation functionality.
    private boolean createAccount(String username, String password) {
        return weightTrackerDatabase.addUser(username, password);
    }
}
