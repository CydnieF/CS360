package com.cs360.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class SMSActivity extends AppCompatActivity {

    // Request code for the SMS permission
    private static final int REQUEST_SMS_PERMISSION = 1;
    private SwitchMaterial notificationsToggle;

    // Override onCreate method
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Initialize views
        FloatingActionButton backArrowButton = findViewById(R.id.backArrowButton);
        backArrowButton.setOnClickListener(v -> {
            // Navigate to DataActivity
            Intent intent = new Intent(SMSActivity.this, DataActivity.class);
            startActivity(intent);
        });

        // Initialize SwitchMaterial
        notificationsToggle = findViewById(R.id.notificationsToggle);
        notificationsToggle.setOnCheckedChangeListener(this::onNotificationsToggleChanged);
    }

    // Method to handle notifications toggle change
    private void onNotificationsToggleChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            showPermissionExplanationDialog();
        } else {
        }
    }

    // Method to show the permission explanation dialog
    private void showPermissionExplanationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enable SMS Notifications")
                .setMessage("Would you like to enable SMS notifications? This will allow the app to send you text messages.")
                .setPositiveButton("Yes", (dialog, which) -> requestSmsPermission())
                .setNegativeButton("No", (dialog, which) -> notificationsToggle.setChecked(false));

        AlertDialog dialog = builder.create();
        dialog.show();

        // Access the title TextView and change its color
        TextView titleTextView = dialog.findViewById(android.R.id.title);
        if (titleTextView != null) {
            titleTextView.setTextColor(Color.parseColor("#678666"));
        }

        // Access the message TextView and change its color
        TextView messageTextView = dialog.findViewById(android.R.id.message);
        if (messageTextView != null) {
            messageTextView.setTextColor(Color.parseColor("#678666"));
        }

        // Access and customize the dialog buttons
        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (positiveButton != null) {
            positiveButton.setTextColor(Color.parseColor("#678666"));
        }

        Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        if (negativeButton != null) {
            negativeButton.setTextColor(Color.parseColor("#678666"));
        }
    }

    // Method to request SMS permission
    private void requestSmsPermission() {
        // Check if the SMS permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        } else {
            // Permission is already granted, enable SMS notifications
            enableSmsNotifications();
        }
    }

    // Method to enable SMS notifications
    private void enableSmsNotifications() {

    }

    // Override onRequestPermissionsResult method
    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Check if the request code matches the one we sent
        if (requestCode == REQUEST_SMS_PERMISSION) {
            // Check if the permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, enable SMS notifications
                enableSmsNotifications();
            } else {
                // Permission denied, handle appropriately
                notificationsToggle.setChecked(false);
            }
        }
    }
}
