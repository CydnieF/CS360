package com.cs360.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.List;

public class DataActivity extends AppCompatActivity {

    // Initialize views
    private GridView dataGrid;
    private FloatingActionButton plusButton;
    private ImageButton settingsButton;
    private WeightTrackerDatabase db;
    private WeightEntryAdapter adapter;
    private List<WeightEntry> weightEntries;

    // Initialize database
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize views
        dataGrid = findViewById(R.id.data_grid);
        plusButton = findViewById(R.id.plusButton);
        settingsButton = findViewById(R.id.settingsButton);

        // Initialize database
        db = WeightTrackerDatabase.getInstance(this);

        // Fetch all weight entries from the database
        weightEntries = db.getAllWeights();

        // Set up the adapter and attach it to the GridView
        adapter = new WeightEntryAdapter(this, weightEntries, db);
        dataGrid.setAdapter(adapter);

        // Handle plus button click to add new data
        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddDataActivity
                Intent intent = new Intent(DataActivity.this, AddDataActivity.class);
                startActivity(intent);
            }
        });

        // Handle settings button click to navigate to SMSActivity
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddDataActivity
                Intent intent = new Intent(DataActivity.this, SMSActivity.class);
                startActivity(intent);
            }
        });
    }

    // Refresh the data when returning to this activity
    @Override
    protected void onResume() {
        super.onResume();
        weightEntries.clear();
        weightEntries.addAll(db.getAllWeights());
        adapter.notifyDataSetChanged();
    }
}
