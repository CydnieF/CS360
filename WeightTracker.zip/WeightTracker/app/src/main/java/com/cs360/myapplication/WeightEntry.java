package com.cs360.myapplication;

public class WeightEntry {

    private int id;
    private String date;
    private double weight;

    // Constructor
    public WeightEntry(int id, String date, double weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    // toString method for debugging
    @Override
    public String toString() {
        return "WeightEntry{" +
                "id=" + id +
                ", date='" + date + '\'' +
                ", weight=" + weight +
                '}';
    }
}
